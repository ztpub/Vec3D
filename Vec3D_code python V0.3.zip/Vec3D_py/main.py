import matlab
import matlab.engine
import pandas as pd
import numpy as np
import time

from scipy import io

eng = matlab.engine.start_matlab()

def write2mat( a_, a_labels, b_, b_labels,txtName):
    io.savemat(txtName, mdict={'Xtrain': a_,'train_labels':a_labels,'Xtest': b_, 'test_labels': b_labels})
    print('write2mat finish')


def read_data():
    Tr_layer1 = pd.read_csv('D:\Project\Vec2image-3D\Vec3D_py\exampledata\Train_cv0_m.csv', header= None)
    Tr_layer2 = pd.read_csv('D:\Project\Vec2image-3D\Vec3D_py\exampledata\Train_cv0_P.csv', header= None)
    Tr_layer3 = pd.read_csv('D:\Project\Vec2image-3D\Vec3D_py\exampledata\Train_cv0_R.csv', header = None)
    Tr_labels = pd.read_csv('D:\Project\Vec2image-3D\Vec3D_py\exampledata\Train_cv0_label.csv', header= None)
    Test_layer1= pd.read_csv('D:\Project\Vec2image-3D\Vec3D_py\exampledata\Test_cv0_m.csv', header= None)
    Test_layer2 = pd.read_csv('D:\Project\Vec2image-3D\Vec3D_py\exampledata\Test_cv0_P.csv', header= None)
    Test_layer3 = pd.read_csv('D:\Project\Vec2image-3D\Vec3D_py\exampledata\Test_cv0_R.csv', header=None)
    Test_labels = pd.read_csv('D:\Project\Vec2image-3D\Vec3D_py\exampledata\Test_cv0_label.csv', header= None)
    a_ = np.empty((3,), dtype=np.object_)
    a_[0] = np.array(Tr_layer1)
    a_[1] = Tr_layer2.values.tolist()
    a_[2] = Tr_layer3.values.tolist()
    a_labels = np.array(Tr_labels, dtype=np.object_)
    b_ = np.empty((3,), dtype=np.object_)
    b_[0] = Test_layer1.values.tolist()
    b_[1] = Test_layer2.values.tolist()
    b_[2] = Test_layer3.values.tolist()
    b_labels = np.array(Test_labels, dtype=np.object_)
    return a_, a_labels, b_, b_labels

if __name__ == '__main__':
    a_, a_labels, b_, b_labels = read_data()
    txtName = 'D:\Project\Vec2image-3D\Vec3D_py\Traindata.mat'
    write2mat(a_, a_labels, b_, b_labels,txtName)
    Method = 'tsne'  # 1) kpca 2) pca 3)tsne
    Dist = 'cosine'  #FortSNE only 1) mahalanobis 2) cosine 3) euclidean 4) chebychev5) correlation 6) hamming(default: cosine)
    ExecutionEnvironment = 'gpu'  # gpu, multi-gpu or cpu
    Aug = 0  # Augment data set 1 else 0
    eng.main_mat(txtName, Method, Dist, ExecutionEnvironment, Aug, nargout=0)

eng.quit()

