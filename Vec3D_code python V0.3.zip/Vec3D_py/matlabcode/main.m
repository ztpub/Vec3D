function  main(dset,b,c,d,Aug)
%% demo for dataset1 
% sampling unbanlanced datasets
%[dset.Xtrain{1},dset.train_labels] = mySMOTE(dset.Xtrain{1},dset.train_labels,10);

% Define parameters for Vec3D and CNN
Parm = Parameters(); 
Parm.Method = [b];
Parm.Dist = c;
Parm.ExecutionEnvironment = d;


% Augment data
if Aug == 1
for i= 1:3
[dset.Xtrain{i},dset.train_labels] = mySMOTE(dset.Xtrain{i}',dset.train_labels',10);
end
end

% Convert expression data to 3D pseudo-image
Out = Prepare_Data_norm2(dset,2,Parm); 
Out.class = dset.class;

%training network
net = makeobjFun(Out,Parm); 

[YPred,probs] = classify(net,Out.XTest); % test the model
accuracy = mean(YPred == Out.YTest) % calculate the accuracy

 %obtain SML by Grad-CAM
SML_class = calculate_SML(net,Out);

 %feature selection
inputSize = net.Layers(1).InputSize(1:2);
classes = net.Layers(end).Classes;
IFMs = featureSelection(SML_class,Out,classes,inputSize);


fileName='D:\Project\Vec2image-3D\Vec3D_py\Result\result_dataset1.mat';
save(fileName,'net','Out','accuracy','SML_class','IFMs')


end
