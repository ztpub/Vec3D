%{
%Kfoldresult = [];
for j = sample
cd Result
fileName=['res_',DataSets{j,1},'_3D.mat'];
load(fileName);
cd ..
species = Out.YTest;
test = Out.XTest;
indices = crossvalind('Kfold',species,10); %10为交叉验证折
for i = 1:10 %实验记进行10次(交叉验证折数)，求10次的平均值作为实验结果，
    index= (indices == i); 
    indextrain = ~index;  %产生测试集合训练集索引
    [class,scores] = classify(net,test(:,:,:,indextrain));
    acc = mean(species(indextrain)==class);
    Kfoldresult{1}(i,j) = acc;   
end

for k = 1:3
cd Result
fileName=['res_',DataSets{j,1},num2str(k),'_1D.mat'];
load(fileName);
cd ..
species = Out.YTest;
test = Out.XTest;
%indices = crossvalind('Kfold',species,10); %10为交叉验证折
for i = 1:10 %实验记进行10次(交叉验证折数)，求10次的平均值作为实验结果，
    index= (indices == i); 
    indextrain = ~index;  %产生测试集合训练集索引
    [class,scores] = classify(net,test(:,:,:,indextrain));
    %classperf(cp,cellstr(class),indextrain);
    acc = mean(species(indextrain)==class);
    %[a,b,c,auc] = perfcurve(species(indextrain),scores(:,2),'S');
    Kfoldresult{k+1}(i,j) = acc;  
end

end
j
end




%% CITE
Kfoldresult = {};
for j = 1:4
cd result
fileName=['resCITE',num2str(j),'.mat'];
load(fileName);
cd ..
species = Out.YTest;
test = Out.XTest;
indices = crossvalind('Kfold',species,10); %10为交叉验证折
for i = 1:10 %实验记进行10次(交叉验证折数)，求10次的平均值作为实验结果，
    index= (indices == i); 
    indextrain = ~index;  %产生测试集合训练集索引
    [class,scores] = classify(net,test(:,:,:,indextrain));
    acc = mean(species(indextrain)==class);
    ari = rand_index(species(indextrain),class, 'adjusted');
    Kfoldresult{1,1}(i,j) = acc;  
    Kfoldresult{2,1}(i,j) = ari;  
end


cd result
fileName = ['resCITE',num2str(j),'_onelayer.mat'];
load(fileName);
cd ..
species = Out.YTest;
test = Out.XTest;
%indices = crossvalind('Kfold',species,10); %10为交叉验证折
for i = 1:10 %实验记进行10次(交叉验证折数)，求10次的平均值作为实验结果，
    index= (indices == i); 
    indextrain = ~index;  %产生测试集合训练集索引
    [class,scores] = classify(net,test(:,:,:,indextrain));
    %classperf(cp,cellstr(class),indextrain);
    acc = mean(species(indextrain)==class);
    ari = rand_index(species(indextrain),class, 'adjusted');
    Kfoldresult{1,2}(i,j) = acc; 
    Kfoldresult{2,2}(i,j) = ari;  
end

for j = 1:4
cd result
fileName = ['resCITE',num2str(j),'_onelayer2.mat'];
load(fileName);
cd ..
species = Out.YTest;
test = Out.XTest;
indices = crossvalind('Kfold',species,10); %10为交叉验证折
for i = 1:10 %实验记进行10次(交叉验证折数)，求10次的平均值作为实验结果，
    index= (indices == i); 
    indextrain = ~index;  %产生测试集合训练集索引
    [class,scores] = classify(net,test(:,:,:,indextrain));
    %classperf(cp,cellstr(class),indextrain);
    acc = mean(species(indextrain)==class);
    ari = rand_index(species(indextrain),class, 'adjusted');
    Kfoldresult{1,3}(i,j) = acc; 
    Kfoldresult{2,3}(i,j) = ari;  
end
j
end

end


  

%% CITE for predict celltypesl1 l2 

%X = {};
cd result
fileName=['resCITE',num2str(6),'.mat'];
load(fileName);
cd ..
species = Out.YTest;
test = Out.XTest;
indices= crossvalind('Kfold',species,10); %10为交叉验证折
for i = 1:10 %实验记进行10次(交叉验证折数)，求10次的平均值作为实验结果，
    index= (indices == i); 
    indextrain = ~index;  %产生测试集合训练集索引
    [class,scores] = classify(net,test(:,:,:,indextrain));
    for j = 1:length(class)
    rng=find(strcmp(dset.test_anno.celltype_l3,cellstr(class(j))));
    Ypred(j,1) = dset.test_anno.celltype_l3(rng(1));
    end
    acc = mean(categorical(dset.test_anno.celltype_l3(indextrain))==categorical(Ypred));
    ari = rand_index(dset.test_anno.celltype_l3(indextrain),Ypred, 'adjusted');
    X{1,1}(i,3) = acc;  
    X{2,1}(i,3) = ari;
    clear Ypred
    i
end
 


%% binary classification
%Kfoldresult = [];
Filename = {'Docetaxel','Gemcitabine','Tamoxifen','Crtuximab','Erlotinib','Gemcitabine_PDX'};
for j = 1:6
cd result
fileName=['res_',Filename{j},'.mat'];
load(fileName);
cd ..
species =[Out.YTest;Out.YValidation];
test = cat(4,Out.XTest,Out.XValidation);
[~,scores] = classify(net,test);
[TPR, FPR, PPV] = prc(species, scores(:,2));
K.TPR{1,j} = TPR';
K.FPR{1,j} = FPR';
K.PPV{1,j} = PPV';

num = length(species);
cd result
fileName=['res_',Filename{j},'_smote.mat'];
load(fileName);
cd ..
species = [Out.YTest;Out.YValidation];
test = cat(4,Out.XTest,Out.XValidation);
index = randperm(length(species),num);
[~,scores] = classify(net,test(:,:,:,index));
[TPR, FPR, PPV] = prc(species(index), scores(:,2));
K.TPR{2,j} = TPR';
K.FPR{2,j} = FPR';
K.PPV{2,j} = PPV';
end
%}  


for k = 1:4
cd result
fileName=['resCITE_FGS_',num2str(k),'.mat'];
load(fileName);
cd ..
species = Out.YTest;
test = Out.XTest;
indices= crossvalind('Kfold',species,10); %10为交叉验证折
for i = 1:10 %实验记进行10次(交叉验证折数)，求10次的平均值作为实验结果，
    index= (indices == i); 
    indextrain = ~index;  %产生测试集合训练集索引
    [class,scores] = classify(net,test(:,:,:,indextrain));
    acc = mean(species(indextrain)'==class);
    ari = rand_index(species(indextrain)',class, 'adjusted');
    X{1,1}(i,k) = acc;  
    X{2,1}(i,k) = ari;
    clear Ypred
    i
end
end




