%Kfoldresult = [];
for j = sample
cd result
fileName=['res_',DataSets{j,1},'_3D.mat'];
load(fileName);
cd ..
species = Out.YTest;
test = Out.XTest;
indices = crossvalind('Kfold',species,10); %10为交叉验证折
for i = 1:10 %实验记进行10次(交叉验证折数)，求10次的平均值作为实验结果，
    index= (indices == i); 
    indextrain = ~index;  %产生测试集合训练集索引
    [class,scores] = classify(net,test(:,:,:,indextrain));
    acc =  rand_index(species(indextrain),class, 'adjusted');
    ARI_singlecell{1}(i,j) = acc;   
end

for k = 1:3
cd Result
fileName=['res_',DataSets{j,1},num2str(k),'_1D.mat'];
load(fileName);
cd ..
species = Out.YTest;
test = Out.XTest;
%indices = crossvalind('Kfold',species,10); %10为交叉验证折
for i = 1:10 %实验记进行10次(交叉验证折数)，求10次的平均值作为实验结果，
    index= (indices == i); 
    indextrain = ~index;  %产生测试集合训练集索引
    [class,scores] = classify(net,test(:,:,:,indextrain));
    acc =  rand_index(species(indextrain),class, 'adjusted');
   ARI_singlecell{k+1}(i,j) = acc;  
end

end
j
end


