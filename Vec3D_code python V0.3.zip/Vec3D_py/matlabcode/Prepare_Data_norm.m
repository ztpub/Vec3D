function Out = Prepare_Data_norm(dset,NORM,Parm)
if exist('Parm')==0
   Parm.Method = ['tSNE']; % other methods 2) kpca or 3) pca 
   Parm.Max_Px_Size = 227;
   Parm.MPS_Fix = 1; % if this val is 1 then screen will be Max_Px_Size x Max_Px_Size (eg 120x120 )
                     % otherwise automatically decided by the distribution
                     % of the input data.
   Parm.ValidRatio = 0.1; % 0.1 of Train data will be used as Validation data
   Parm.Seed = 108; %random seed
   Parm.SnowFall_A = Parm.Max_Px_Size;
   Parm.SnowFall_B = Parm.Max_Px_Size;
   Parm.SnowFall = 1;
end 

%Take data on "as is" basis; i.e., no change in Train and Test data
TrueLabel = dset.train_labels;
Out.YTest=categorical(dset.test_labels)';
Out.YTrain=categorical(TrueLabel)';

q=1:length(TrueLabel);
clear idx

num_class = length(dset.class);
for j=1:num_class
   % rng=find(dset.train_labels==dset.class(j));
   rng=find(strcmp(dset.train_labels,dset.class(j)));
   % rng=q(double(TrueLabel)==j);
    rand('seed',Parm.Seed);
    idx{j} = rng(randperm(length(rng),round(length(rng)*Parm.ValidRatio)));
end
idx=cell2mat(idx);
dset.XValidation= dset.Xtrain(:,idx);
dset.Xtrain(:,idx) = [];
Out.YValidation = Out.YTrain(idx);
Out.YTrain(idx) = [];

%%
switch NORM
    case 1
        % Norm-3 in org code
        Out.Norm=1;
    %fprintf(Parm.fid,'\nNORM-1\n');
    fprintf('\nNORM-1\n');
    %########### Norm-1 ###################
    for dsz=1:size(dset.Xtrain,3)
        Out.Max=max(dset.Xtrain(:,:,dsz)')';
        Out.Min=min(dset.Xtrain(:,:,dsz)')';
        dset.Xtrain(:,:,dsz)=(dset.Xtrain(:,:,dsz)-Out.Min)./(Out.Max-Out.Min);
        dset.XValidation(:,:,dsz) = (dset.XValidation(:,:,dsz)-Out.Min)./(Out.Max-Out.Min);
        dset.Xtest(:,:,dsz) = (dset.Xtest(:,:,dsz)-Out.Min)./(Out.Max-Out.Min);
    end
    dset.Xtrain(isnan(dset.Xtrain))=0;
    dset.Xtest(isnan(dset.Xtest))=0;
    dset.XValidation(isnan(dset.XValidation))=0;
    dset.XValidation(dset.XValidation>1)=1;
    dset.XValidation(dset.XValidation<0)=0;
    dset.Xtest(dset.Xtest>1)=1;
    dset.Xtest(dset.Xtest<0)=0;
    %######################################
   
    
    case 2
        % norm-6 in org ocde
        Out.Norm=2;
    %fprintf(Parm.fid,'\nNORM-2\n');
    fprintf('\nNORM-2\n');
    %########### Norm-2 ###################
    for dsz=1:size(dset.Xtrain,3)
        Out.Min=min(dset.Xtrain(:,:,dsz)')';
        dset.Xtrain(:,:,dsz)=log(dset.Xtrain(:,:,dsz)+abs(Out.Min)+1);
    
        indV = dset.XValidation(:,:,dsz)<Out.Min;
        indT = dset.Xtest(:,:,dsz)<Out.Min;
        for j=1:size(dset.Xtrain,1)
            dset.XValidation(j,indV(j,:),dsz)=Out.Min(j); 
            dset.Xtest(j,indT(j,:),dsz)=Out.Min(j);
        end
  
        dset.XValidation(:,:,dsz) = log(dset.XValidation(:,:,dsz)+abs(Out.Min)+1);
        dset.Xtest(:,:,dsz)=log(dset.Xtest(:,:,dsz)+abs(Out.Min)+1);
        Out.Max=max(max(dset.Xtrain(:,:,dsz)));
        dset.Xtrain(:,:,dsz)=dset.Xtrain(:,:,dsz)/Out.Max;
        dset.XValidation(:,:,dsz) = dset.XValidation(:,:,dsz)/Out.Max;
        dset.Xtest(:,:,dsz) = dset.Xtest(:,:,dsz)/Out.Max;
    end
    dset.XValidation(dset.XValidation>1)=1;
    dset.Xtest(dset.Xtest>1)=1;
    %######################################
end

%%
Q.Max_Px_Size = Parm.Max_Px_Size; % <----- NOTE
Q.Method=Parm.Method;
Q.Dist= Parm.Dist;
 disp('multi-omics data used for Cart2Pixel');
   for dsz=1:size(dset.Xtrain,3)
    Q.data = dset.Xtrain(:,:,dsz);
    [Out.xp,Out.yp,Out.A,Out.B,Out.Base] = Cart2Pixel(Q,Q.Max_Px_Size,Q.Max_Px_Size);
   for j=1:length(Out.YTrain)
        Out.XTrain(:,:,dsz,j) = ConvPixel(dset.Xtrain(:,j,dsz),Out.xp,Out.yp,Out.A,Out.B,Out.Base,0);
   end
    for j=1:length(Out.YTest)
        Out.XTest(:,:,dsz,j) = ConvPixel(dset.Xtest(:,j,dsz),Out.xp,Out.yp,Out.A,Out.B,Out.Base,0);
    end
    for j=1:length(Out.YValidation)
        Out.XValidation(:,:,dsz,j) = ConvPixel(dset.XValidation(:,j,dsz),Out.xp,Out.yp,Out.A,Out.B,Out.Base,0);
    end
   end   
   Out.C = size(Out.XTrain,3);
end

