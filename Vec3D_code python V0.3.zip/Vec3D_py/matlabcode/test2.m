function y = test2(a)
data = load(a);
x = data.dset.Xtrain{1};
y = mean(x);
%y = a+b
end


