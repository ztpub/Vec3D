function Out = Prepare_Data_norm2(dset,NORM,Parm)
if exist('Parm')==0
   Parm.Method = ['tSNE']; % other methods 2) kpca or 3) pca 
   Parm.Max_Px_Size = 227;
   Parm.MPS_Fix = 1; % if this val is 1 then screen will be Max_Px_Size x Max_Px_Size (eg 120x120 )
                     % otherwise automatically decided by the distribution
                     % of the input data.
   Parm.ValidRatio = 0.1; % 0.1 of Train data will be used as Validation data
   Parm.Seed = 108; %random seed
   Parm.SnowFall_A = Parm.Max_Px_Size;
   Parm.SnowFall_B = Parm.Max_Px_Size;
   Parm.SnowFall = 1;
end 

%Take data on "as is" basis; i.e., no change in Train and Test data
TrueLabel = dset.train_labels;
Out.YTest=categorical(dset.test_labels)';
Out.YTrain=categorical(TrueLabel)';
train_layers = length(dset.Xtrain);
q=1:length(TrueLabel);
clear idx


num_class = length(dset.class);
for j=1:num_class
%    rng=find(dset.train_labels==dset.class(j));
    rng=find(strcmp(dset.train_labels,dset.class(j)));
   % rng=q(double(TrueLabel)==j);
    rand('seed',Parm.Seed);
    idx{j} = rng(randperm(length(rng),round(length(rng)*Parm.ValidRatio)));
end
idx=cell2mat(idx);
for i =1:train_layers
dset.XValidation{i} = dset.Xtrain{i}(:,idx);
dset.Xtrain{i}(:,idx) = [];
end
Out.YValidation = Out.YTrain(idx);
Out.YTrain(idx) = [];

%%
switch NORM
    case 1
        % Norm-3 in org code
        Out.Norm=1;
    %fprintf(Parm.fid,'\nNORM-1\n');
    fprintf('\nNORM-1\n');
    for i = 1:trainlayers
    %########### Norm-1 ###################
    for dsz=1:size(dset.Xtrain{1},3)
        Out.Max=max(dset.Xtrain{1}(:,:,dsz)')';
        Out.Min=min(dset.Xtrain{1}(:,:,dsz)')';
        dset.Xtrain{1}(:,:,dsz)=(dset.Xtrain{1}(:,:,dsz)-Out.Min)./(Out.Max-Out.Min);
        dset.XValidation{1}(:,:,dsz) = (dset.XValidation{1}(:,:,dsz)-Out.Min)./(Out.Max-Out.Min);
        dset.Xtest{1}(:,:,dsz) = (dset.Xtest{1}(:,:,dsz)-Out.Min)./(Out.Max-Out.Min);
    end
    dset.Xtrain{1}(isnan(dset.Xtrain))=0;
    dset.Xtest{1}(isnan(dset.Xtest))=0;
    dset.XValidation{1}(isnan(dset.XValidation))=0;
    dset.XValidation{1}(dset.XValidation>1)=1;
    dset.XValidation{1}(dset.XValidation<0)=0;
    dset.Xtest{1}(dset.Xtest>1)=1;
    dset.Xtest{1}(dset.Xtest<0)=0;
    %######################################
    end
    
    case 2
        % norm-6 in org ocde
        Out.Norm=2;
    %fprintf(Parm.fid,'\nNORM-2\n');
    fprintf('\nNORM-2\n');
    %########### Norm-2 ###################
    for i = 1:train_layers
        Out.Min=min(dset.Xtrain{i}')';
        dset.Xtrain{i}=log(dset.Xtrain{i}+abs(Out.Min)+1);
    
        indV = dset.XValidation{i}<Out.Min;
        indT = dset.Xtest{i}<Out.Min;
        for j=1:size(dset.Xtrain{i},1)
            dset.XValidation{i}(j,indV(j,:))=Out.Min(j); 
            dset.Xtest{i}(j,indT(j,:))=Out.Min(j);
        end
  
        dset.XValidation{i} = log(dset.XValidation{i}+abs(Out.Min)+1);
        dset.Xtest{i}=log(dset.Xtest{i}+abs(Out.Min)+1);
        Out.Max=max(max(dset.Xtrain{i}));
        dset.Xtrain{i}=dset.Xtrain{i}/Out.Max;
        dset.XValidation{i}= dset.XValidation{i}/Out.Max;
        dset.Xtest{i} = dset.Xtest{i}/Out.Max;
     dset.XValidation{i}(dset.XValidation{i}>1)=1;
     dset.Xtest{i}(dset.Xtest{i}>1)=1;
    %######################################
    end
end
%%
Q.Max_Px_Size = Parm.Max_Px_Size; % <----- NOTE
Q.Method=Parm.Method;
Q.Dist= Parm.Dist;
 disp('multi-omics data used for Cart2Pixel');
   for dsz=1:train_layers
    Q.data = dset.Xtrain{dsz};
    [Out.xp,Out.yp,Out.A,Out.B,Out.Base] = Cart2Pixel(Q,Q.Max_Px_Size,Q.Max_Px_Size);
   for j=1:length(Out.YTrain)
        Out.XTrain(:,:,dsz,j) = ConvPixel(dset.Xtrain{dsz}(:,j),Out.xp,Out.yp,Out.A,Out.B,Out.Base,0);
   end
    for j=1:length(Out.YTest)
        Out.XTest(:,:,dsz,j) = ConvPixel(dset.Xtest{dsz}(:,j),Out.xp,Out.yp,Out.A,Out.B,Out.Base,0);
    end
    for j=1:length(Out.YValidation)
        Out.XValidation(:,:,dsz,j) = ConvPixel(dset.XValidation{dsz}(:,j),Out.xp,Out.yp,Out.A,Out.B,Out.Base,0);
    end
    Out.Xp{dsz} = Out.xp;
    Out.Yp{dsz} = Out.yp;
    
   end   
   Out.C = size(Out.XTrain,3);
   
end
