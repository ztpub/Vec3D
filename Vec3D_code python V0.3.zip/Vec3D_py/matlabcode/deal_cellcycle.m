data = readtable('scSeq_data.csv');
celltype = readtable('gene.csv','ReadVariableNames',false);

index = find(strcmp(celltype.Var4,'NotAssigned"')==1);
celltype(index,:) = [];
gene = data.Var1;
data(:,1) = [];
data = table2array(data);
data(:,index) = [];


for  i = 1:length(gene)
p(i,1) = anova1(data(i,:),celltype.Var4,"off");
i
end
index = find(p<0.5);
data = data(index,:);
gene = gene(index,:);

dset.train_labels = celltype.Var4;
dset.class = unique(dset.train_labels);
dset.Xtrain = data;

num_class = length(dset.class);
for j=1:num_class
   % rng=find(dset.train_labels==dset.class(j));
   rng=find(strcmp(dset.train_labels,dset.class(j)));
   % rng=q(double(TrueLabel)==j);
    rand('seed',Parm.Seed);
    idx{j} = rng(randperm(length(rng),round(length(rng)*0.1)));
end
idx=cell2mat(idx);
dset.XValidation = dset.Xtrain(:,idx,:);
dset.Xtrain(:,idx,:) = [];
Out.YValidation = Out.YTrain(idx);
Out.YTrain(idx) = [];




