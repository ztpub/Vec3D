function [SML_class] = calculate_SML(net,Out)
inputSize = net.Layers(1).InputSize(1:2);
classes = net.Layers(end).Classes;

nclass = max(double(classes));
Rclass=zeros(inputSize(1),inputSize(2),1,nclass);

for cls = 1:nclass 
    R=zeros(inputSize(1),inputSize(2));
    SMPLE =find(Out.YTrain==classes(cls));
   for Sample = 1:length(SMPLE)
   [classfn,score] = classify(net,Out.XTrain(:,:,:,SMPLE(Sample)));
    map = gradCAM(net,Out.XTrain(:,:,:,SMPLE(Sample)),classfn);
     R= R + map;
   end
   SML_class(:,:,1,cls)=R/length(SMPLE);
    cls
end
end