
%%% figure for ACC and AUC for drug data 
%{
cmp = linspecer(4);
for i = 1:6
x{i}= [Kfoldresult1.acc(:,i),Kfoldresult.acc(:,i),Kfoldresult1.acc(:,i+6),Kfoldresult.acc(:,i+6)];
end
name1 = {'Deepinsight3D','Vec3D','Deepinsight3D+Aug','Vec3D+smote'}
name2 = {'Doc','Gem-TCGA','Tam','Crt','Erl','Gem-PDX'};
bpColors = cool(6);
figure
g = boxplotGroup(x,'PrimaryLabels',name2, ...
'SecondaryLabels',name1, ...
'GroupLabelType','Vertical', 'PlotStyle','Compact',...
'BoxStyle','filled','Colors',cmp,'GroupType','withinGroups')
set(findobj(g.boxplotGroup,'tag','Whisker'),'LineWidth',1);
ylim([0.5,1])

set(g.xline,'LabelVerticalAlignment','bottom')
medOuter = findobj(g.boxplotGroup,'tag','MedianOuter');
set(medOuter,'MarkerFaceColor', 'k')
medInner = findobj(g.boxplotGroup,'tag','MedianInner');
set(medInner,'MarkerEdgeColor', 'w')

outliers = findobj(g.boxplotGroup,'Tag','Outliers');
set(outliers, 'Marker','*')
set(findobj(g.boxplotGroup,'tag','Whisker'),'LineWidth',1)

g.axis.XTickLabelRotation = 90; 
g.axis.XAxis.FontName = 'fixedwidth';
g.axis.XAxis.FontWeight = 'bold';

groupX = [cell2mat(get(g.xline,'value'));max(xlim(g.axis))];
yl = ylim(g.axis);
ph = gobjects(1,numel(groupX)-1);
for i = 1:numel(groupX)-1
    ph(i) = patch(g.axis, ...
        groupX(i+[0,1,1,0]),...
        yl([1,1,2,2]),...
        cmp(i,:),...
        'FaceAlpha',0.1,...
        'LineStyle','none');
end
uistack(ph,'bottom')
g.axis.YGrid = 'on';
g.axis.XGrid = 'on';

%% roc for drug
 k = 4;
 x{k}= [];
 y{k} =[];
for i = 1:5
for j = 7:12
    x{k} = [x{k};Kfoldresult1.a{i,j}];
    y{k} = [y{k};Kfoldresult1.b{i,j}];
end 
end

for i = 1:4
plot(sort(x{i}),sort(y{i}),'Color',bpColors(i,:))
hold on
end

%% prc for drug
figure
cmp = linspecer(4);
for i = 1:6
subplot(2,3,i)
plot(Kfoldresult1.a{2,i},Kfoldresult1.b{2,i}, '-', 'color', cmp(1,:), 'linewidth', 1.5);
hold on;
plot(Kfoldresult.a{2,i},Kfoldresult.b{2,i}, '-', 'color', cmp(2,:), 'linewidth', 1.5);
plot(Kfoldresult1.a{2,i+6},Kfoldresult1.b{2,i+6}, '-', 'color', cmp(3,:), 'linewidth', 1.5);
plot(Kfoldresult.a{2,i+6},Kfoldresult.b{2,i+6}, '-', 'color', cmp(4,:), 'linewidth', 1.5);
xlabel('FPR'); ylabel('TPR'); 
end
%legend('Vec3D','Vec3D_smote','Deepinsight3D','Deepinsight3D_Aug')
%title('PRC curves');


figure
cols = [200 45 43; 37 64 180; 0 176 80; 0 0 0]/255;
for i = 1:6
subplot(2,3,i)
plot(K.TPR{1,i},K.PPV{1,i}, '-', 'color', cmp(1,:), 'linewidth', 1.5);
hold on;
plot(K.TPR{2,i}, K.PPV{2,i}, '-', 'color', cmp(3,:), 'linewidth', 1.5);
plot(K.TPR{3,i}, K.PPV{3,i}, '-', 'color', cmp(2,:), 'linewidth', 1.5);
plot(K.TPR{4,i}, K.PPV{4,i}, '-', 'color', cmp(4,:), 'linewidth', 1.5);
xlabel('TPR'); ylabel('PPV'); 
end
legend('Vec3D','Vec3D_smote','Deepinsight3D','Deepinsight3D_Aug')
%title('ROC curves');

%% single-cell ACC
m = mean(Kfoldresult{1,1});
m(2,:) = mean(Kfoldresult{1,2});
m(3,:) = mean(Kfoldresult{1,3});
m(4,:)= mean(Kfoldresult{1,4});

e= max(Kfoldresult{1,1})-min(Kfoldresult{1,1});
e(2,:) = max(Kfoldresult{1,2})-min(Kfoldresult{1,2});
e(3,:) = max(Kfoldresult{1,3})-min(Kfoldresult{1,3});
e(4,:)= max(Kfoldresult{1,4})-min(Kfoldresult{1,4});

cmp = linspecer(4);
barSettings = {'EdgeColor',[0,0.4,0.4]}; 
lineSettings = {'linestyle','none','linewidth',0.5,'Color','k'}; 
errorbarbar(1:20,m',e',barSettings,lineSettings)
labels = {'Aoria','Bladder','BrainMyeloid','BrainNonMyeloid','Diaphragm','Fat',...
    'Heart','Kidney','LargeIntestine','LimbMuscle','Liver','Lung',...
    'MammaryGland','Marrow','Pancreas','Skin','Spleen','Thymus',...
    'Tongue','Trachea'};
set(gca,'xtick',1:20,'xticklabel',labels);
ylim([0.8,1])



%% single-cell ARi
m = mean(ARI_singlecell{1,1});
m(2,:) = mean(ARI_singlecell{1,2});
m(3,:) = mean(ARI_singlecell{1,3});
m(4,:)= mean(ARI_singlecell{1,4});

e= max(ARI_singlecell{1,1})-min(ARI_singlecell{1,1});
e(2,:) = max(ARI_singlecell{1,2})-min(ARI_singlecell{1,2});
e(3,:) = max(ARI_singlecell{1,3})-min(ARI_singlecell{1,3});
e(4,:)= max(ARI_singlecell{1,4})-min(ARI_singlecell{1,4});

cmp = linspecer(4);
barSettings = {'EdgeColor',[0,0.4,0.4]}; 
lineSettings = {'linestyle','none','linewidth',0.5,'Color','k'}; 
errorbarbar(1:20,m',e',barSettings,lineSettings)
labels = {'Aoria','Bladder','BrainMyeloid','BrainNonMyeloid','Diaphragm','Fat',...
    'Heart','Kidney','LargeIntestine','LimbMuscle','Liver','Lung',...
    'MammaryGland','Marrow','Pancreas','Skin','Spleen','Thymus',...
    'Tongue','Trachea'};
set(gca,'xtick',1:20,'xticklabel',labels);
ylim([0.6,1])

%%single-cell contour
cmp = [1 0 0;1 0.1 0.1;1 0.2 0.2;1 0.3 0.3;1 0.4 0.4;1 0.5 0.5;
    1 0.6 0.6;1 0.7 0.7;1 0.8 0.8;1 0.9 0.9;1 1 1];
for  i = 1:11
    map(i,:) = cmp(12-i,:);
end
figure;
subplot(1,4,1)
[C,h]=contourf(Rclass1(:,:,1,3),5);
clabel(C,h) 
colormap(map)
subplot(1,4,2)
[C,h]=contourf(Rclass2(:,:,1,3),5);
clabel(C,h) 
colormap(map)
subplot(1,4,3)
[C,h]=contourf(Rclass3(:,:,1,3),5);
clabel(C,h) 
colormap(map)
subplot(1,4,4)
[C,h]=contourf(Rclass4(:,:,1,3),5);
clabel(C,h) 
colormap(map)

%% single-cell histfit
for i = 1:5
cmp = linspecer(4);
y = Rclass1(:,:,1,i);
y = y(:);
h1 = histfit(y,20,'kernel');
x1{1,i} = h1(2).XData;
x1{2,i} = h1(2).YData;
hold on
y = Rclass2(:,:,1,i);
y = y(:);
h2 = histfit(y,20,'kernel');
x2{1,i} = h2(2).XData;
x2{2,i} = h2(2).YData;
y = Rclass3(:,:,1,i);
y = y(:);
h3 = histfit(y,20,'kernel');
x3{1,i} = h3(2).XData;
x3{2,i} = h3(2).YData;
y = Rclass4(:,:,1,i);
y = y(:);
h4 =histfit(y,20,'kernel');
x4{1,i} = h4(2).XData;
x4{2,i} = h4(2).YData;
end

figure
for i = 1:5
subplot(2,5,i)
T1 = area(x1{1,i},x1{2,i}); 
T1.FaceColor=cmp(1,:); 
T1.FaceAlpha=0.5;
T1.EdgeColor = cmp(1,:);
hold on
T2 = area(x2{1,i},x2{2,i}); 
T2.FaceColor=cmp(2,:); 
T2.FaceAlpha=0.5;
T2.EdgeColor = cmp(2,:);
T3 = area(x3{1,i},x3{2,i}); 
T3.FaceColor=cmp(3,:); 
T3.FaceAlpha=0.5;
T3.EdgeColor = cmp(3,:);
subplot(2,5,i+5)
T4 = area(x4{1,i},x4{2,i}); 
T4.FaceColor=cmp(4,:); 
T4.FaceAlpha=0.5;
T4.EdgeColor = cmp(4,:);
end



%% CITE ACC and ARI
m = mean(Kfoldresult{1,1});
m(2,:) = mean(Kfoldresult{1,2});
m(3,:) = mean(Kfoldresult{1,3});

e= max(Kfoldresult{1,1})-min(Kfoldresult{1,1});
e(2,:) = max(Kfoldresult{1,2})-min(Kfoldresult{1,2});
e(3,:) = max(Kfoldresult{1,3})-min(Kfoldresult{1,3});


cmp = linspecer(4);
barSettings = {'EdgeColor',[0,0.4,0.4]}; 
lineSettings = {'linestyle','none','linewidth',0.5,'Color','k'}; 
errorbarbar(1:3,m',e',barSettings,lineSettings)
labels = {'celltype1','celltype2','celltype3'};
set(gca,'xtick',1:3,'xticklabel',labels);
ylim([0.8,1])


 m = mean(Kfoldresult{2,1});
m(2,:) = mean(Kfoldresult{2,2});
m(3,:) = mean(Kfoldresult{2,3});

e= max(Kfoldresult{2,1})-min(Kfoldresult{2,1});
e(2,:) = max(Kfoldresult{2,2})-min(Kfoldresult{2,2});
e(3,:) = max(Kfoldresult{2,3})-min(Kfoldresult{2,3});

cmp = linspecer(4);
barSettings = {'EdgeColor',[0,0.4,0.4]}; 
lineSettings = {'linestyle','none','linewidth',0.5,'Color','k'}; 
errorbarbar(1:3,m',e',barSettings,lineSettings)
labels = {'celltype1','celltype2','celltype3'};
set(gca,'xtick',1:3,'xticklabel',labels);
ylim([0.8,1])




%% CITE predict celltypel1 l2

m = mean(X{1,1});
e= max(X{1,1})-min(X{1,1});
cmp = linspecer(3);
bar(1,m(1),'FaceColor',cmp(1,:))
hold on
bar(2,m(2),'FaceColor',cmp(2,:))
bar(3,m(3),'FaceColor',cmp(3,:))
ylim([0.8,1])
plot(0.8:0.04:1.16,X{1}(:,1),'k.','MarkerSize',8)
plot(1.8:0.04:2.16,X{1}(:,2),'k.','MarkerSize',8)
plot(2.8:0.04:3.16,X{1}(:,3),'k.','MarkerSize',8)


m = mean(X{2,1});
e= max(X{2,1})-min(X{2,1});
cmp = linspecer(3);
labels = {'CellType1','CellType2','CellType3'};
bar(1,m(1),'FaceColor',cmp(1,:))
hold on
bar(2,m(2),'FaceColor',cmp(2,:))
bar(3,m(3),'FaceColor',cmp(3,:))
ylim([0.8,1])
plot(0.8:0.04:1.16,X{2,1}(:,1),'k.','MarkerSize',8)
plot(1.8:0.04:2.16,X{2,1}(:,2),'k.','MarkerSize',8)
plot(2.8:0.04:3.16,X{2,1}(:,3),'k.','MarkerSize',8)




%% CITE heatmap
cmp = [1 0 0;1 0.1 0.1;1 0.2 0.2;1 0.3 0.3;1 0.4 0.4;1 0.5 0.5;
    1 0.6 0.6;1 0.7 0.7;1 0.8 0.8;1 0.9 0.9;1 1 1];
for  i = 1:11
    map(i,:) = cmp(12-i,:);
end
for  k = 1:4
    figure
    subplot(1,3,3);
    imagesc(Rclass(:,:,1,39),'AlphaData',0.7);
    colormap(map)
    hold on
    plot(Out.Yp{1},Out.Xp{1},'k.')
    plot(Out.Yp{2},Out.Xp{2},'k.')
    plot(Out.Yp{1}(Genes{1,39}),Out.Xp{1}(Genes{1,39}),'b.')
    plot(Out.Yp{2}(Genes{2,39}),Out.Xp{2}(Genes{2,39}),'b.','MarkerSize',6)
     plot(Out.Yp{2}(53),Out.Xp{2}(53),'b^','MarkerSize',6)
    xlim([0,225])
    ylim([0,225])
    hold off;

end


figure
plot(Out.Yp{1},Out.Xp{1},'k.')
hold on
plot(Out.Yp{2},Out.Xp{2},'k.')
plot(Out.Yp{1}(9875),Out.Xp{1}(9875),'ro','MarkerSize',12)




%% CITE-shuffle
m = mean(X{1,1});
e= max(X{1,1})-min(X{1,1});
m(2,:) = mean(X{2,1});
e(2,:)= max(X{2,1})-min(X{2,1});

cmp = linspecer(4);
barSettings = {'EdgeColor',[0,0.4,0.4]}; 
lineSettings = {'linestyle','none','linewidth',0.5,'Color','k'}; 
errorbarbar(1:2,m,e,barSettings,lineSettings)



%% CITE violin plot
class = unique(dset.train_anno.celltype_l1);
k = 1:12016;
index = setdiff(k,CITE_features{1});
for i = 1:2264
%index = find(strcmp(dset.train_anno.celltype_l1,class{j})==1);
x(i,1) = std(dset.Xtrain{1}(CITE_features{1}(i),:))/mean(dset.Xtrain{1}(CITE_features{1}(i),:));
end

for i = 1:9752
%index = find(strcmp(dset.train_anno.celltype_l1,class{j})==1);
x = [x;std(dset.Xtrain{1}(index(i),:))/mean(dset.Xtrain{1}(index(i),:))];
end

X = x(:);
Y = {'FGs'};
Y = repmat(Y,1,2264);
Y1 = {'-FGs'};
Y1 = repmat(Y1,1,9752);
Y = [Y,Y1];
vs = violinplot(x,Y);
al_goodplot(x(134:end),1);
al_goodplot(x(1:133),4);
[~,p] = ttest2(x(1:133),x(134:end));
[~,p1] = ttest2(x(1:2264),x(2265:end));



%% CRC contour
cmp = [1 0 0;1 0.2 0.2;1 0.4 0.4;
    1 0.6 0.6;1 0.8 0.8;1 1 1];
for  i = 1:6
    map(i,:) = cmp(7-i,:);
end
figure;
for i = 1:3
subplot(1,3,i)
[C,h]=contourf(Rclass(:,:,1,i),5);
clabel(C,h) 
colormap(map)
end


%% Violinplot CRC
class = unique(labels);

for i = 1:3
    index = find(strcmp(labels,class{i}));
    %x3(:,i) = std(exp(Genes{1,3},index),0,2)./mean(exp(Genes{1,3},index),2);
    x3(:,i) = std(methy(Genes{2,3},index),0,2)./mean(methy(Genes{2,3},index),2);
    %x3(:,i) = mean(methy(Genes{2,3},index),2);
end

cmp = linspecer(3);
figure
subplot(1,3,1)
al_goodplot(x1(:,1),1,0.3,cmp(1,:));
al_goodplot(x1(:,2),2,0.3,cmp(2,:));
al_goodplot(x1(:,3),3,0.3,cmp(3,:));
ylim([0,500])

subplot(1,3,2)
al_goodplot(x2(:,1),1,0.3,cmp(1,:));
al_goodplot(x2(:,2),2,0.3,cmp(2,:));
al_goodplot(x2(:,3),3,0.3,cmp(3,:));
ylim([0,500])

subplot(1,3,3)
al_goodplot(x3(:,1),1,0.3,cmp(1,:));
al_goodplot(x3(:,2),2,0.3,cmp(2,:));
al_goodplot(x3(:,3),3,0.3,cmp(3,:));
ylim([0,500])

figure
subplot(1,2,1)
al_goodplot(x1,[],0.3,cmp);
subplot(1,2,2)
al_goodplot(x2,[],0.3,cmp);



%%  Figure5 NK contour
for i = 1:5
subplot(1,5,i)
plot(Out.Yp{1},Out.Xp{1},'.','Color',[0.7 0.7 0.7])
hold on
plot(Out.Yp{2},Out.Xp{2},'.','Color',[0.7 0.7 0.7])
[U,V] = gradient(Rclass(:,:,:,37+i),0.2,0.2);
hold on
U1 = U(1:20:220,1:20:220);
V1= V(1:20:220,1:20:220);
contour(Rclass(:,:,:,37+i))
colormap(map)
quiver(1:20:220,1:20:220,U1,V1,'k','AutoScaleFactor',1)
axis equal
hold off
end


%% Figure5 venn
figure
VN=venn(Genes{1,38},Genes{1,39},Genes{1,40},Genes{1,41},Genes{1,42},Genes{1,43});
VN=VN.labels('NK Proliferating','NK-1','NK-2','NK-3','NK-4','NK-CD56bright');   
VN=VN.draw();
colorList= linspecer(6);
for i=1:6
    VN.setPatchN(i,'FaceColor',colorList(i,:),'EdgeColor',colorList(i,:))
end

figure
VN=venn(Genes{2,38},Genes{2,39},Genes{2,40},Genes{2,41},Genes{2,42},Genes{2,43});
VN=VN.labels('NK Proliferating','NK-1','NK-2','NK-3','NK-4','NK-CD56bright');   
VN=VN.draw();
colorList= linspecer(6);
for i=1:6
    VN.setPatchN(i,'FaceColor',colorList(i,:),'EdgeColor',colorList(i,:))
end


%% Figure5 contour2 
cmp = [1 0 0;1 0.1 0.1;1 0.2 0.2;1 0.3 0.3;1 0.4 0.4;1 0.5 0.5;
    1 0.6 0.6;1 0.7 0.7;1 0.8 0.8;1 0.9 0.9;1 1 1];
for  i = 1:11
    map(i,:) = cmp(12-i,:);
end
figure
for i = 1:6
subplot(2,3,i)
x1 = Out.Yp{1};
y1 = Out.Xp{1};
index1 = find(x1<=180);
index2 = find(y1<=180);
index = intersect(index1,index2);
plot(x1(index),y1(index),'.','Color',[0.7 0.7 0.7])
hold on
plot(x1(Genes{1,37+i}),y1(Genes{1,37+i}),'b.')
hold on
x2 = Out.Yp{2};
y2 = Out.Xp{2};
index1 = find(x2<=180);
index2 = find(y2<=180);
index = intersect(index1,index2);
plot(x2(index),y2(index),'.','Color',[0.7 0.7 0.7])
plot(x2(Genes{2,37+i}),y2(Genes{2,37+i}),'b.')
[U,V] = gradient(Rclass(:,:,:,37+i),0.2,0.2);
hold on
U1 = U(1:20:180,1:20:180);
V1= V(1:20:180,1:20:180);
contour(Rclass(1:180,1:180,:,37+i),'LineWidth',1.5)
colormap(map)
quiver(1:20:180,1:20:180,U1,V1,'k','AutoScaleFactor',1)
title(class(37+i))
axis equal
hold off
end

%% sankey plot
inter_var = {};
inter_num = [];
for i = 38:43
    for j =37
        inter_var = [inter_var;class(i),class(j)];
        inter_num=[inter_num;length(intersect(Genes{1,i},Genes{1,j}))];
    end
end

inter_var = cellstr(inter_var);
List={};
for i =1:length(inter_num)
List=[List;inter_var(i,1),inter_num(i),inter_var(i,2)];
end
colorList= linspecer(13);
axis([0,2,0,1])
sankeyHdl=sankey2([],'XLim',[0,2],'YLim',[0,1],'PieceWidth',0.15,'List',List,'Color',colorList);



%% figure 3SI vec3D vs Vec2image
m = mean(Kfoldresult{1,1});
m(2,:) = mean(acc);
e= max(Kfoldresult{1,1})-min(Kfoldresult{1,1});
e(2,:) = max(acc)-min(acc);

cmp = linspecer(2);
barSettings = {'EdgeColor',[0,0.4,0.4]}; 
lineSettings = {'linestyle','none','linewidth',0.5,'Color','k'}; 
errorbarbar(1:20,m',e',barSettings,lineSettings)
labels = {'Aoria','Bladder','BrainMyeloid','BrainNonMyeloid','Diaphragm','Fat',...
    'Heart','Kidney','LargeIntestine','LimbMuscle','Liver','Lung',...
    'MammaryGland','Marrow','Pancreas','Skin','Spleen','Thymus',...
    'Tongue','Trachea'};
set(gca,'xtick',1:20,'xticklabel',labels);
ylim([0.8,1])



%% plot for simulated data
figure
cmp = linspecer(2);
position1 = 0.9:1:3.9;
boxplot(x1,'positions',position1,'Colors',cmp(1,:),'Widths',0.25,'Labels',{});
hold on
position2 = 1.2:1:4.2;
boxplot(x2,'positions',position2,'Colors',cmp(2,:),'Widths',0.25,'Labels',{});

plot(0.86:0.02:0.94,x1(:,1),'.','MarkerEdgeColor','k','MarkerSize',12)
plot(1.86:0.02:1.94,x1(:,2),'.','MarkerEdgeColor','k','MarkerSize',12)
plot(2.86:0.02:2.94,x1(:,3),'.','MarkerEdgeColor','k','MarkerSize',12)
plot(3.86:0.02:3.94,x1(:,4),'.','MarkerEdgeColor','k','MarkerSize',12)

plot(1.16:0.02:1.24,x2(:,1),'.','MarkerEdgeColor','k','MarkerSize',12)
plot(2.16:0.02:2.24,x2(:,2),'.','MarkerEdgeColor','k','MarkerSize',12)
plot(3.16:0.02:3.24,x2(:,3),'.','MarkerEdgeColor','k','MarkerSize',12)
plot(4.16:0.02:4.24,x2(:,4),'.','MarkerEdgeColor','k','MarkerSize',12)

%% plot MUSE data
m = mean(x);
m(2,:) = mean(x1);
e= max(x)-min(x);
e(2,:) = max(x1)-min(x1);

cmp = linspecer(2);
barSettings = {'EdgeColor',[0,0.4,0.4]}; 
lineSettings = {'linestyle','none','linewidth',0.5,'Color','k'}; 
errorbarbar(1:10,m',e'/5,barSettings,lineSettings)
labels = {'0.1','0.2','0.3','0.4','0.5','0.6',...
    '0.7','0.8','0.9','1'};
set(gca,'xtick',1:10,'xticklabel',labels);
ylim([0,1])
%}

%% plot MUSE data
figure
cmp = linspecer(2);
position1 = 0.9:1:9.9;
boxplot(x,'positions',position1,'Colors',cmp(1,:),'Widths',0.25,'Labels',{});
hold on
position2 = 1.2:1:10.2;
boxplot(x1,'positions',position2,'Colors',cmp(2,:),'Widths',0.25,'Labels',{});

for i = 0:9
plot(0.86+i:0.02:0.94+i,x(:,i+1),'.','MarkerEdgeColor','k','MarkerSize',12)
plot(1.16+i:0.02:1.24+i,x1(:,i+1),'.','MarkerEdgeColor','k','MarkerSize',12)
end
ylim([0.2,1])




%% plot DPLFC data
color = linspecer(7);
gscatter(obs.Var4(index),obs.Var5(index),obs.Var3(index),color,'.',8);


%% plot DLPFC data
figure
cmp = linspecer(2);
position1 = 1:6;
boxplot(x,'positions',position1,'Colors',cmp(2,:),'Widths',0.25,'Labels',{});
hold on
position2 = 7;
boxplot(x1,'positions',position2,'Colors',cmp(1,:),'Widths',0.25,'Labels',{});

plot(0.96:0.02:1.02,x(:,1),'.','MarkerEdgeColor','k','MarkerSize',12)
plot(1.96:0.02:2.02,x(:,2),'.','MarkerEdgeColor','k','MarkerSize',12)
plot(2.96:0.02:3.02,x(:,3),'.','MarkerEdgeColor','k','MarkerSize',12)
plot(3.96:0.02:4.02,x(:,4),'.','MarkerEdgeColor','k','MarkerSize',12)

plot(4.96:0.02:5.02,x(:,5),'.','MarkerEdgeColor','k','MarkerSize',12)
plot(5.96:0.02:6.02,x(:,6),'.','MarkerEdgeColor','k','MarkerSize',12)
plot(6.96:0.02:7.02,x1(:,1),'.','MarkerEdgeColor','k','MarkerSize',12)
