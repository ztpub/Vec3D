function main_mat(A,b,c,d,Aug)
dset = load(A);
dset.class = unique(dset.train_labels);
cd matlabcode\
main(dset,b,c,d,Aug)
cd ..
%y = a+b
end
